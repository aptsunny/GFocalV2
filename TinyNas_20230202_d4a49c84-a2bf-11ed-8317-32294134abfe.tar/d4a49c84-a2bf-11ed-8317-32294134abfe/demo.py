# Copyright (c) Alibaba, Inc. and its affiliates.

import ast
import os

import torch
from masternet import MasterNet
def get_backbone(filename,
                 load_weight=True,
                 network_id=0,
                 task='classification'):
    # load best structures
    with open(filename, 'r') as fin:
        content = fin.read()
        output_structures = ast.literal_eval(content)

    network_arch = output_structures['space_arch']
    best_structures = output_structures['best_structures']

    # If task type is classification, param num_classes is required
    out_indices = (1, 2, 3, 4) if task == 'detection' else (4, )
    backbone = MasterNet(
            structure_info=best_structures[network_id],
            out_indices=out_indices,
            num_classes=1000,
            task=task)

    return backbone, network_arch


if __name__ == '__main__':
    # make input
    x = torch.randn(1, 3, 224, 224)

    # instantiation
    backbone, network_arch = get_backbone('best_structure.json')

    print(backbone)
    # forward
    input_data = [x] 
    pred = backbone(*input_data)
    
    #print output
    for o in pred:
        print(o.size())
